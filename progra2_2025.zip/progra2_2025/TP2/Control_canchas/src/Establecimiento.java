import java.time.LocalDate;
import java.util.ArrayList;

public class Establecimiento {
    private final String deporte1="futbol"; //en mayuscula
    private String deporte2="padel";
    private int cantidadReservasParaSocio=4;
    private double valorCanchaPadel=100; //estos van en cancha;
    private double valorCanchaFutbol=400;
    private double descuento=.10;
    private int cantdidadCanchaFutbol=2;
    private int cantidadCanchaPadel=4;


   private ArrayList<Reserva>reservas;

    public Establecimiento() {

        this.reservas=new ArrayList<>();
    }

    public void reservarCancha(Reserva r) {
        Usuario usuario = r.getUsuario();
        Cancha cancha = r.getCancha();
        LocalDate fecha = r.getFecha();
        double duracion = r.getTiempo();
        Reserva nuevaReserva;
        nuevaReserva = new Reserva(r.getUsuario().getNombreUsuario(), r.getCancha(),  r.getTiempo(),r.getFecha());
        if (r.getCancha().getDeporte().equals(deporte1) && (cantdidadCanchaFutbol > 0)) {
            reservas.add(nuevaReserva);
            cantdidadCanchaFutbol--;
        } else if (r.getCancha().getDeporte().equals(deporte2) && (cantidadCanchaPadel > 0)) {
            reservas.add(nuevaReserva);
            cantidadCanchaPadel--;
        } else {
            System.out.println("no se pudo efectuar la reserva");

        }
    }


    //para ser socio es necesario haber reservado un turno al menos 4 veces en los
    //últimos dos meses
    public boolean esSocio(Usuario u) {
        int cantidadReservas = 0;
        LocalDate fechaControl = LocalDate.now().minusMonths(2);
        String posibleSocio = u.getNombreUsuario();
        for (Reserva r : reservas) {
            if (r.getUsuario().equals(u.getNombreUsuario()) && r.getFecha().isAfter(fechaControl)) {
                cantidadReservas++;
            }

        }
        return (cantidadReservas >= cantidadReservasParaSocio);

    }


}
