import java.time.LocalDate;

public class Reserva {
   private Cancha c;
   private Usuario u;
   private double tiempo;
   LocalDate fecha;
   ;

    public Reserva(Cancha c, Usuario u, double tiempo,LocalDate fecha ) {
        this.c = c;
        this.u = u;
        this.tiempo = tiempo;
        this.fecha=fecha;

    }

    public Reserva(String nombreUsuario, Cancha cancha, double tiempo, LocalDate fecha) {
    }

    public Cancha getCancha() {
        return c;
    }

    public void setC(Cancha c) {
        this.c = c;
    }

    public Usuario getUsuario(){
        return this.u;
    }

    public double getTiempo() {
        return tiempo;
    }

    public void setTiempo(double tiempo) {
        this.tiempo = tiempo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}
