
public class Usuario {

    private String nombreUsuario;

    public Usuario(String nombreUsuario)
    {
        this.nombreUsuario = nombreUsuario;
    }



    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
}
