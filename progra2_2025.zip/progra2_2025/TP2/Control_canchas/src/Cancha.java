
public class Cancha {

      private String deporte;


    public Cancha( String deporte) {

        this.deporte = deporte;//debe ser futbol o padel
    }



    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }
}