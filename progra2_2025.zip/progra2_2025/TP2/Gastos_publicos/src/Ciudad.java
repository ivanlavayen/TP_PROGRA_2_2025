/*Un país tiene que controlar el gasto público de las ciudades con más de 100.000
habitantes. Para ello, tiene información del monto recaudado por cada ciudad a través de
cinco diferentes tipos de impuestos (denominados, aquí, de imp1, imp2, imp3, imp4 e
imp5) e información acerca de gastos realizados en mantenimiento de la ciudad. Este
país necesita un sistema que le informe cuales son las ciudades que gastan más de lo
que recaudan, y las provincias que tienen más de la mitad de las ciudades en condición
de déficit.
Consejo: Tener en cuenta la información que contienen los distintos impuestos
Extra: ¿En que afecta el tamaño de la ciudad?*/
public class Ciudad {
    private final static int CANT_HAB_CONTROL=100000;
    private String ciudad;
    private String pcia;
    private double imp1;
    private double imp2;
    private double imp3;
    private double imp4;
    private double imp5;
    private int cantidadHabitantes;

    private double gastosMantenimieto;

    public Ciudad(String ciudad, String pcia, double imp1, double imp2, double imp3, double imp4, double imp5,
                  int cantidadHabitantes, double gastosMantenimieto) {
        this.ciudad = ciudad;
        this.pcia = pcia;
        this.imp1 = imp1;
        this.imp2 = imp2;
        this.imp3 = imp3;
        this.imp4 = imp4;
        this.imp5 = imp5;
        this.cantidadHabitantes = cantidadHabitantes;
        this.gastosMantenimieto = gastosMantenimieto;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public double getImp1() {
        return imp1;
    }

    public void setImp1(double imp1) {
        this.imp1 = imp1;
    }

    public double getImp2() {
        return imp2;
    }

    public void setImp2(double imp2) {
        this.imp2 = imp2;
    }

    public double getImp3() {
        return imp3;
    }

    public void setImp3(double imp3) {
        this.imp3 = imp3;
    }

    public double getImp4() {
        return imp4;
    }

    public void setImp4(double imp4) {
        this.imp4 = imp4;
    }

    public double getImp5() {
        return imp5;
    }

    public void setImp5(double imp5) {
        this.imp5 = imp5;
    }

    public int getCantidadHabitantes() {
        return cantidadHabitantes;
    }

    public String getPcia() {
        return pcia;
    }

    public void setPcia(String pcia) {
        this.pcia = pcia;
    }

    public void setCantidadHabitantes(int cantidadHabitantes) {
        this.cantidadHabitantes = cantidadHabitantes;
    }

    public double getGastosMantenimieto() {
        return gastosMantenimieto;
    }

    public void setGastosMantenimieto(double gastosMantenimieto) {
        this.gastosMantenimieto = gastosMantenimieto;
    }

    public double getRecaudacionTotal(){
        return this.getImp1()+
                this.getImp2()+
                this.getImp3()+
                this.getImp4()+
                this.getImp5();
    }

    public boolean ciudadDeficitaria(){
        if(this.getCantidadHabitantes()>=CANT_HAB_CONTROL){
           return this.getRecaudacionTotal()-this.getGastosMantenimieto()<0;
        }
        return false;
    }

}
