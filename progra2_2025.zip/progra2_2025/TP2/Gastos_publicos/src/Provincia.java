import java.util.ArrayList;

public class Provincia {
    private String nombreProvincia;
    ArrayList<Ciudad>ciudades;


    public Provincia(String nombreProvincia) {
        this.nombreProvincia=nombreProvincia;
        this.ciudades = new ArrayList<>();
    }

    public String getNombreProvincia() {
        return nombreProvincia;
    }

    public void setNombreProvincia(String nombreProvincia) {
        this.nombreProvincia = nombreProvincia;
    }

    public void addCiudad(Ciudad nuevaCiudad){
        if(nuevaCiudad.getPcia().equals(nombreProvincia)){
            ciudades.add(nuevaCiudad);
        }
    }

    public ArrayList<Ciudad>getCiudades(){
        return new ArrayList<>();
    }

    public ArrayList<Ciudad>ciudadesConDeficit(){
        ArrayList<Ciudad>ciudadesDeficitarias=new ArrayList<>();
        for(Ciudad c:ciudades){
            if(c.ciudadDeficitaria()){
                ciudadesDeficitarias.add(c);
            }
        }
        return ciudadesDeficitarias;
    }

}
