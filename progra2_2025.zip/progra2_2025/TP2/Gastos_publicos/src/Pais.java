import java.util.ArrayList;

public class Pais {
    ArrayList<Provincia>provincias;

    public Pais() {
        this.provincias = new ArrayList<>();
    }

    public  void addProvincias(Provincia nuevaProvincia){
        if(!provincias.contains(nuevaProvincia)){
            provincias.add(nuevaProvincia);
        }
    }



    public ArrayList<Provincia> getProvincias() {
        return new ArrayList<>();
    }

    //las provincias que tienen más de la mitad de las ciudades en condición
    //de déficit.
    public ArrayList<Provincia> getProvinciasConDeficit() {
        ArrayList<Provincia> provinciasConProblemas = new ArrayList<>();
        for (Provincia p : provincias) {
          int ciudadesEnDeficit = p.ciudadesConDeficit().size();
          int totalCiudadesPcia= p.getCiudades().size();
          if (ciudadesEnDeficit > (totalCiudadesPcia / 2)) {
            provinciasConProblemas.add(p);
          }
        }
        return provinciasConProblemas;
       }

 }