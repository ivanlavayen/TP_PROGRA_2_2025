import java.time.LocalTime;
import java.util.ArrayList;
import java.time.Duration;

public class Reunion {
    String lugar;
    ArrayList<Participantes>participantes;
    String tema;
    Duration duracion; //expresado en minutos;
    LocalTime hora;

    public Reunion(String lugar, String tema, Duration
            duracion, LocalTime hora) {
        this.lugar = lugar;
        this.tema = tema;
        this.duracion = duracion;
        this.hora = hora;
        this.participantes=new ArrayList<>();
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public Duration getDuracion() {
        return duracion;
    }

    public void setDuracion(Duration duracion) {
        this.duracion = duracion;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public void addParticipante(Participantes nuevoParticipante){
        participantes.add(nuevoParticipante);
    }
    public ArrayList<Participantes> getParticipantes(){
        return new ArrayList<>(participantes);
    }
    public LocalTime getHoraFin(){
        return this.getHora().plus(this.getDuracion());
    }
}
