import java.util.ArrayList;

public class Agenda {
    private ArrayList<Reunion>reuniones;

    public Agenda() {
    this.reuniones=new ArrayList<>();
    }
    public void addReunion(Reunion nuevaReunion) {
        boolean hayConflicto = false;
        for (Reunion r : reuniones) {
            if (nuevaReunion.getHora().isBefore(r.getHoraFin()) &&
                    nuevaReunion.getHoraFin().isAfter(r.getHora())){
                hayConflicto = true;

            }

        }

           if (hayConflicto) {
               System.out.println("ya hay una reunion agendada para esa hora");

            }
           else{
                reuniones.add(nuevaReunion);
               System.out.println("se ha agregado una reunion");
            }

    }
}
