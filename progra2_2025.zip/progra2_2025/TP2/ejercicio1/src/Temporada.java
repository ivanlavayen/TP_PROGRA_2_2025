import java.util.ArrayList;

public class Temporada {
    ArrayList<Episodio> episodios;


    /*Obtener el total de episodios vistos de una temporada particular*/
    public int cantidadVistos() {
        int cantidad = 0;
        for (Episodio ep : episodios) {
            if (ep.isEpisodioVisto()) {
                cantidad++;
            }
        }
        return cantidad;

    }

    /* Determinar si se vio todos los episodios de la serie.*/

    public boolean fueronVistosTodos() {
        boolean seVieron = true;
        for (Episodio e : episodios) {
            if (!e.isEpisodioVisto()) {
                seVieron = false;

            }
        }
        return seVieron;
    }


    public double getPromedio() {
        int suma = 0;
        int cant = 0;
        for (Episodio e : episodios) {
            if (e.isEpisodioVisto()) {
                suma = suma + e.getCalificacion();

            }
            cant++;
        }
        return suma / cant;

    }

}
