/* Cada episodio posee un título, una descripción, un flag indicando
si ya se vio el episodio y una calificación dada (con valores de 0 a 5). Si no se vio un
episodio particular, la calificación dada será un valor negativo.

● Ingresar la calificación de un episodio. Si el valor ingresado como calificación
no es correcto imprimir un mensaje por pantalla y no cambiar el valor anterior.

*/
public class Episodio{
    private static final int CALIFICACION_MINIMA=0;
    private static final int CALIFICACION_MAX=5;
    private String titulo;
    private  String descripcion;
    private boolean episodioVisto;
    private int calificacion;

    public Episodio(String titulo, String descripcion) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.episodioVisto = false;
        this.calificacion = -1;
    }

    public boolean isEpisodioVisto() {
        return episodioVisto;
    }



    public int getCalificacion() {
        if(!this.episodioVisto){
            return -1;
        }
        else {
            return calificacion;
        }
    }

    public void setCalificacion(int nuevaCalificacion) {
        if ((nuevaCalificacion >= CALIFICACION_MINIMA) &&
                (nuevaCalificacion <= CALIFICACION_MAX)) {
            this.calificacion = nuevaCalificacion;
            this.episodioVisto=true;
        } else {
            System.out.println("valor incorrecto, la calificacion debe ser entre 0 y 5");
        }
    }
}
