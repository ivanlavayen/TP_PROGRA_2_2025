// creo la clase Proceso con tamanio como unico atributo
public class Proceso {
    private int tamanio;

    public Proceso(int tamanio) {
        this.tamanio = tamanio;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }
}
