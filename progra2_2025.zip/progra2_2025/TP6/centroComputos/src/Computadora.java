//creo la Clase Computadora con velocidad como unico atributo
public class Computadora {
    private int velocidad;

    public Computadora(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
}
