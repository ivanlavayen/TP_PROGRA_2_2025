import java.time.LocalDate;

public class Planta {
    private static int contador=1;//defino una variable static para el contador
    private int id;
    private String nombreCientifico;
    private String nombreVulgar;
    private String paisOrigen;
    private LocalDate fechaDeCompra;

    public Planta(  String nombreCientifico, String nombreVulgar,
                  String paisOrigen, LocalDate fechaDeCompra) {
        this.nombreCientifico = nombreCientifico;
        this.nombreVulgar = nombreVulgar;
        this.paisOrigen = paisOrigen;
        this.fechaDeCompra = fechaDeCompra;
        this.id=contador; //al id le asigno el valor que tiene el contador
        contador++;//incremento el contador, el siguiente id sera una mas que el actual
        //asi se arma un autoincremental
    }

    public  int getId() {
        return id;}

    public String getNombreCientifico() {
        return nombreCientifico;
    }

    public void setNombreCientifico(String nombreCientifico) {
        this.nombreCientifico = nombreCientifico;
    }

    public String getNombreVulgar() {
        return nombreVulgar;
    }

    public void setNombreVulgar(String nombreVulgar) {
        this.nombreVulgar = nombreVulgar;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public LocalDate getFechaDeCompra() {
        return fechaDeCompra;
    }

    public void setFechaDeCompra(LocalDate fechaDeCompra) {
        this.fechaDeCompra = fechaDeCompra;
    }
    @Override
    public String toString(){
        return "id" +id+ "nombreVulgar "+nombreVulgar;
    }
}
