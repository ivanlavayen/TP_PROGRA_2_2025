import java.time.LocalDate;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
       /* 1 - El Jardín privado
        Se desea implementar un sistema de gestión de plantas para un Jardín privado, de cada planta
        se guarda su nombre científico, su nombre común, país de origen, fecha de compra y un
        identificador único. Cada vez que se crea una planta nueva para la colección, se debe asignar
        un número nuevo de forma automática e incremental. ;*/
        LocalDate fechaCompra=LocalDate.now();
        Planta p1=new Planta("abetus coniferus","pino","italia",fechaCompra);
        Planta p2=new Planta("citrus","naranja","alemania",fechaCompra);

        System.out.println(p1);
        System.out.println(p2);
    }
}