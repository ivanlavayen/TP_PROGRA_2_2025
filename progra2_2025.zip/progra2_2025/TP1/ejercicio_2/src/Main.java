//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.*;
public class Main {



    public static void main(String[] args) {
        // Código a ejecutar

    Electrodomestico elect1=new Electrodomestico();
        System.out.println( elect1.getNombre());
        System.out.println(elect1.getColor());
        elect1.setConsumo(1000);
        System.out.println( elect1.getPrecio());
        System.out.println(elect1.calcularBalance());
        System.out.println(elect1.esAltaGama());
        System.out.println(elect1.esBajoConsumo());


    Electrodomestico elect2= new Electrodomestico();
        elect2.setNombre("tv");
        System.out.println( elect2.getNombre());
        elect2.setColor("red");
        System.out.println(elect2.getColor());

        elect1.setConsumo(15);
        System.out.println( elect2.getPrecio());
        System.out.println(elect2.calcularBalance());
        System.out.println(elect2.esAltaGama());
        System.out.println(elect2.esBajoConsumo());





    Electrodomestico elect3=new Electrodomestico("licuadora",43982,
                                            "green",120,4);

       System.out.println( elect3.getNombre());
       System.out.println(elect3.getColor());
       System.out.println( elect3.getPrecio());
       System.out.println(elect3.calcularBalance());
       System.out.println(elect3.esAltaGama());
       System.out.println(elect3.esBajoConsumo());
    }

}