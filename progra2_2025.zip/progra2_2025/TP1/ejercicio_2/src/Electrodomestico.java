
/*2 Electrodomésticos
Crear una clase Electrodoméstico con las siguientes características:
Atributos son nombre, precio base, color, consumo energético y peso.
Valores por defecto:
● El color por defecto es gris plata.
● El consumo energético 10 Kw.
● Precio base 100 pesos.
● El peso es 2 kg.
Implementar todos los constructores.
La funcionalidad de la clase es la siguiente:
● Todos los métodos get y set.


*/
public class Electrodomestico {
    private static final int INDICECONSUMO=45;
    private static final int INDICEBALANCE=3;
    private String nombre;
    private double precio=100;
    private String color="gris";
    private  int consumo=10;
    private double peso=2;

    public Electrodomestico() {
        this.nombre = "Sin nombre";
        this.precio = 100;
        this.color = "gris plata";
        this.consumo = 10;
        this.peso = 2;
    }

    public Electrodomestico(String nombre, double precio,
                            String color, int consumo, double peso) {
        this.nombre = nombre;
        this.precio = precio;
        this.color = color;
        this.consumo = consumo;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getConsumo() {
        return consumo;
    }

    public void setConsumo(int consumo) {
        this.consumo = consumo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    /*informar si es bajo consumo*/
    public boolean esBajoConsumo(){
        return this.getConsumo()<INDICECONSUMO;
    }


    /*● Calcular el balance, el mismo es el resultado de dividir el costo por el peso*/
    public double calcularBalance(){
        return this.getPrecio()/this.getPeso();
    }

    /*● Indicar si un producto es de alta gama, el balance es mayor que 3*/
    public boolean esAltaGama(){
        return this.calcularBalance()>INDICEBALANCE;
    }
}
