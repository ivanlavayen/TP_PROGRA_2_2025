/*
3 Elementos Geométricos
Implementar la clase punto geométrico, la cual posee dos valores de coordenada X, Y.
El valor por defecto de los mismos es (0,0)
La funcionalidad que posee la clase es la siguiente:


La clase Math de Java define un método de clase sqrt para el cálculo de la raíz
cuadrada.
*/

import java.lang.Math;
public class PuntoGeomtrico {
    private int punto_x;
    private int punto_y;


    public PuntoGeomtrico(){
        this.punto_x=0;
        this.punto_y=0;
    }
    public PuntoGeomtrico(int punto_x, int punto_y) {
        this.punto_x = punto_x;

    }

    public int getPunto_x() {
        return punto_x;
    }

    public void setPunto_x(int punto_x) {
        this.punto_x = punto_x;
    }

    public int getPunto_y() {
        return punto_y;
    }

    public void setPunto_y(int punto_y) {
        this.punto_y = punto_y;
    }



    /*● Desplazar el punto en el plano. Se encarga de trasladar el punto a otra posición
del plano. Para esto se incrementan los valores de X e Y en una cierta cantidad
(cierto desplazamiento en X y cierto desplazamiento en Y).*/

    public void desplazamiento(int dx, int dy){
        this.punto_x=this.punto_x+dx;
        this.punto_y=this.punto_y+dy;
    }

    /*● Calcular la distancia euclídea. Dado un punto es posible establecer la distancia
euclídea con otro punto acorde a la siguiente formula:
Distancia2 = ( X1 – X2 )2 + (Y1 – Y2)2 */

    public double calculoEuclideo(PuntoGeomtrico otroPunto){
        double diferenciaX = Math.pow(this.punto_x - otroPunto.getPunto_x(), 2);
        double diferenciaY = Math.pow(this.punto_y - otroPunto.getPunto_y(), 2);
        return  Math.sqrt(diferenciaX + diferenciaY);

    }


}
