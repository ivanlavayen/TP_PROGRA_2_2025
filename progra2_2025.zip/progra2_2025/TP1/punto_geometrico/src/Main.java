//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Crear un punto por defecto (0,0)
        PuntoGeomtrico p1 = new PuntoGeomtrico();
        System.out.println("Punto p1 creado en: (" + p1.getPunto_x() + ", " + p1.getPunto_y() + ")");

        // Crear otro punto con valores específicos
        PuntoGeomtrico p2 = new PuntoGeomtrico(3, 4);
        System.out.println("Punto p2 creado en: (" + p2.getPunto_x() + ", " + p2.getPunto_y() + ")");

        // Desplazar el punto p1
        p1.desplazamiento(5, 7);
        System.out.println("Punto p1 desplazado a: (" + p1.getPunto_x() + ", " + p1.getPunto_y() + ")");

        // Calcular la distancia entre p1 y p2
        double distancia = p1.calculoEuclideo(p2);
        System.out.println("La distancia euclídea entre p1 y p2 es: " + distancia);
    }
}