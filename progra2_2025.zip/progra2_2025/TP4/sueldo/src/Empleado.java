import java.util.ArrayList;


public class Empleado {
    double salario;
    private ArrayList<Venta>ventas;

    public Empleado(double salario) {
        this.salario = salario;
        this.ventas=new ArrayList<>();
    }
    public Empleado(){

    }

    public void addVenta(Venta nuevaVenta){
        this.ventas.add(nuevaVenta);
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    public ArrayList<Venta>getVentas(){
        return new ArrayList<>();
    }


}
