public class Venta {
    private double monto;
    private Empleado empleado;

    public Venta(double monto, Empleado empleado) {
        this.monto = monto;
        this.empleado =new Empleado();
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }
}
