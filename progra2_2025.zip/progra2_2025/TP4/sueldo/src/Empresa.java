import java.util.ArrayList;

public class Empresa {

    private ArrayList<Empleado>empleados;


    public Empresa(int diasLiquidacion) {

        this.empleados=new ArrayList<>();


    }

    public void addEmleado(Empleado nuevoEmpleado){
        this.empleados.add(nuevoEmpleado);
    }

    public ArrayList<Empleado>getEmpleados(){
        return new ArrayList<>(this.empleados);
    }

    public double calcularTotalSalarioSemanal(){
        double total=0;
        for(Empleado e:empleados){
            total=total+e.getSalario();
        }
        return total;
    }

}
