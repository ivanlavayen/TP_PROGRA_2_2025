public class EmpleadoHorasExtras extends Empleado{

    private int horasExtras;
    private double adicionalPorHoraExtra;



    public EmpleadoHorasExtras(double salario, int horasExtras, double adicionalPorHoraExtra) {
        super(salario);
        this.horasExtras = horasExtras;
        this.adicionalPorHoraExtra = adicionalPorHoraExtra;
    }

    public int getHorasExtras() {
        return horasExtras;
    }

    public void setHorasExtras(int horasExtras) {
        this.horasExtras = horasExtras;
    }

    public double getAdicionalPorHoraExtra() {
        return adicionalPorHoraExtra;
    }

    public void setAdicionalPorHoraExtra(double adicionalPorHoraExtra) {
        this.adicionalPorHoraExtra = adicionalPorHoraExtra;
    }

    @Override
    public double getSalario(){
        return super.getSalario()+this.getHorasExtras()*this.getAdicionalPorHoraExtra();
    }
}
