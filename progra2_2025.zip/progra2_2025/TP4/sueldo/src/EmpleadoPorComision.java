import java.lang.reflect.Array;
import java.util.ArrayList;

public class EmpleadoPorComision extends  Empleado{
    private double comision;

    public EmpleadoPorComision(double salario, double comision) {
        super(salario);
        this.comision = comision;
    }



    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    public int getCantidadVentas(){
              return this.getVentas().size();
    }


    @Override
    public double getSalario() {
        return super.getSalario()+this.getCantidadVentas()*this.getComision();
    }
}
