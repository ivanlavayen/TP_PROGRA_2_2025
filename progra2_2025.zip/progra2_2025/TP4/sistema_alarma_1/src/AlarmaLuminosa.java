public class AlarmaLuminosa extends Alarma{
    private Luz luz;

    public AlarmaLuminosa(boolean sensorMov, boolean sensorRotura, boolean sensorApertura) {
        super(sensorMov, sensorRotura, sensorApertura);
        this.luz=new Luz();
    }

    @Override
   public boolean comprobarEstado(){
        if(super.comprobarEstado()){
            luz.encender();
        }
        return false;
    }
}
