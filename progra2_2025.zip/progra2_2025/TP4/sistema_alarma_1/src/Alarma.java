public class Alarma {
    private boolean sensorMov;
    private boolean sensorRotura;
    private boolean sensorApertura;
    private  Timbre timbre;


    public Alarma(boolean sensorMov, boolean sensorRotura, boolean sensorApertura) {
        this.sensorMov = sensorMov;
        this.sensorRotura = sensorRotura;
        this.sensorApertura = sensorApertura;
        this.timbre = new Timbre();
    }

    public boolean comprobarEstado() {
        if ((this.sensorApertura) || (this.sensorRotura) || (this.sensorMov)) {
            timbre.sonar();

        }
        return false;
    }



}
