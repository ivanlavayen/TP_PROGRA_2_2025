public class Luz {

    public void encender(){
        System.out.println("luces encendidas");
    }
}
