public class Timbre {
    public  void sonar(){
        System.out.println("ring");
    }
}

