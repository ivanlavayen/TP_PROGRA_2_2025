//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        /*Implementar en java el sistema de registro de una empresa. Este sistema de
registro permite exportar un String con el listado de todas las personas asociadas a
la empresa. En el String, en cada línea (usar ‘\n’ para concatenar los Strings) se
muestra el cargo de la persona, su nombre, apellido y edad. En el sistema existen
distintos tipos de roles: el empleado, del cual, además del nombre, apellido y edad,
se guarda el número de legajo y su sueldo; el usuario final, del cual se guarda el
nombre, apellido, edad, nombre de usuario y password; y el jerárquico, del cual se
registra su nombre, apellido, edad, número de legajo, sueldo y una lista de
empleados a cargo.*/
    Persona p1=new Persona("Ivan","lavayen",54);
    Persona p2=new Persona("elina","arrozeres",52);
    Empleado e1=new Empleado("pepe","lopez",34,123,4565.65);
    Jerarquico j1=new Jerarquico("luis","garcia",60,544,24524);
Empresa empresa1=new Empresa();
empresa1.addPesona(p1);
empresa1.addPesona(p2);
empresa1.addPesona(e1);
empresa1.addPesona(j1);

        System.out.println(empresa1);



    }


}