import java.util.ArrayList;

public class Empresa {
    private ArrayList<Persona> personas;

    public Empresa() {
        this.personas = new ArrayList<>();
    }

    public void addPesona(Persona nuevaPersona){
        personas.add(nuevaPersona);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (personas != null && !personas.isEmpty()) {
            for (Persona p : personas) {
                // Se asume que la clase Persona tiene un toString() funcional
                sb.append(p.toString()).append("\n");
            }
            // Elimina la última línea nueva para un formato más limpio
            sb.setLength(sb.length() - 1);
        } else {
            return "No hay personas en la lista.";
        }
        return sb.toString();
    }


}


