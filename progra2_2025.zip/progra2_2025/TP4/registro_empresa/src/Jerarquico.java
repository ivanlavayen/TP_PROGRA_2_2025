import java.util.ArrayList;

public class Jerarquico extends Empleado{
    private ArrayList<Empleado>empleadosAcargo;

    public Jerarquico(String nombre,String apellido,int edad,int legajo,double sueldo){
        super(nombre,apellido,edad,legajo,sueldo);
        this.empleadosAcargo=new ArrayList<>();

    }
    public void addEmpleadoAcarco(Empleado e){
        if(!empleadosAcargo.contains(e)){
            empleadosAcargo.add(e);
        }
        else{
            System.out.println("el empleado ya esta a su cargo");
        }
    }
}
