import java.time.LocalDate;

/*Los productos frescos deben llevar la fecha de
envasado y la granja de origen*/
public class ProductoFresco extends ProductoDeGranja{
    private LocalDate fechaEnvasado;
    private String granjaOrigen;


    public ProductoFresco(String producto,LocalDate fechaVto, int nroLote, LocalDate
                            fechaEnvasado, String granjaOrigen){
        super(producto, fechaVto, nroLote);
        this.fechaEnvasado=fechaEnvasado;
        this.granjaOrigen=granjaOrigen;
    }

    public LocalDate getFechaEnvasado() {
        return fechaEnvasado;
    }

    public void setFechaEnvasado(LocalDate fechaEnvasado) {
        this.fechaEnvasado = fechaEnvasado;
    }

    public String getGranjaOrigen() {
        return granjaOrigen;
    }

    public void setGranjaOrigen(String granjaOrigen) {
        this.granjaOrigen = granjaOrigen;
    }

    @Override
    public String toString() {
        return super.toString() +"granja"+ this.getGranjaOrigen()+"fecha envasado"
                +this.getFechaEnvasado();
    }
}
