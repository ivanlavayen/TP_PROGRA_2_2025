import java.time.LocalDate;

/*Los productos congelados por agua deben llevar la
información de la salinidad del agua con que se realizó la congelación en gramos de sal por
litro de agua.*/
public class ProductoCongeladoPorAgua extends ProductoRefrigerado{
    private double salinidadAguaHielo;

    public ProductoCongeladoPorAgua(String producto, LocalDate fechaVto, int nroLote,
                                    LocalDate fechaEnvasado, String granjaOrigen,
                                    String codigoOrganismoSupervisor, double temperaturaMantenimiento,
                                    double salinidadAguaHielo){
        super(producto,fechaVto,nroLote,fechaEnvasado,granjaOrigen,
                codigoOrganismoSupervisor,temperaturaMantenimiento);
        this.salinidadAguaHielo=salinidadAguaHielo;
    }

    public double getSalinidadAguaHielo() {
        return salinidadAguaHielo;
    }

    public void setSalinidadAguaHielo(double salinidadAguaHielo) {
        this.salinidadAguaHielo = salinidadAguaHielo;
    }

    @Override
    public String toString(){
        return super.toString()+"salinindad agua"+getSalinidadAguaHielo();
    }
}
