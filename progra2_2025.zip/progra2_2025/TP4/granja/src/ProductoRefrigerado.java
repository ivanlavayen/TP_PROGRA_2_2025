import java.time.LocalDate;

/* Los productos refrigerados deben llevar el código del
organismo de supervisión alimentaria, la fecha de envasado, la temperatura de mantenimiento
recomendada y la granja de origen. */
public class ProductoRefrigerado extends ProductoFresco{
    private String codigoOrganismoSupervisor;
    private double temperaturaMantenimiento;

    public ProductoRefrigerado(String producto, LocalDate fechaVto, int nroLote,
                               LocalDate fechaEnvasado, String granjaOrigen,
                               String codigoOrganismoSupervisor,double temperaturaMantenimiento){
        super (producto, fechaVto, nroLote,fechaEnvasado,granjaOrigen);
        this.codigoOrganismoSupervisor=codigoOrganismoSupervisor;
        this.temperaturaMantenimiento=temperaturaMantenimiento;

    }

    public String getCodigoOrganismoSupervisor() {
        return codigoOrganismoSupervisor;
    }

    public void setCodigoOrganismoSupervisor(String codigoOrganismoSupervisor) {
        this.codigoOrganismoSupervisor = codigoOrganismoSupervisor;
    }

    public double getTemperaturaMantenimiento() {
        return temperaturaMantenimiento;
    }

    public void setTemperaturaMantenimiento(double temperaturaMantenimiento) {
        this.temperaturaMantenimiento = temperaturaMantenimiento;
    }

    @Override
    public String toString(){
        return super.toString()+"codigo supervisor"+this.getCodigoOrganismoSupervisor()+
                "temperatura mantenimineto"+this.getTemperaturaMantenimiento();
    }
}
