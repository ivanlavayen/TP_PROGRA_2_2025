import java.time.LocalDate;

/*Los productos congelados por aire deben llevar la información de
la composición del aire con que fue congelado (% de nitrógeno, % de oxígeno, % de dióxido
de carbono y % de vapor de agua)*/
public class ProductoCongeladoPorAire extends ProductoRefrigerado {
    private double nitrogeno;
    private double oxigeno;
    private double co2;
    private double vaporH2O;

    public ProductoCongeladoPorAire(String producto, LocalDate fechaVto, int nroLote, LocalDate fechaEnvasado,
                                    String granjaOrigen, String codigoOrganismoSupervisor, double temperaturaMantenimiento,
                                    double nitrogeno, double oxigeno, double co2, double vaporH2O) {
        super(producto, fechaVto, nroLote, fechaEnvasado, granjaOrigen
                , codigoOrganismoSupervisor, temperaturaMantenimiento);
        this.nitrogeno = nitrogeno;
        this.oxigeno = oxigeno;
        this.co2 = co2;
        this.vaporH2O = vaporH2O;

    }

    public double getNitrogeno() {
        return nitrogeno;
    }

    public void setNitrogeno(double nitrogeno) {
        this.nitrogeno = nitrogeno;
    }

    public double getOxigeno() {
        return oxigeno;
    }

    public void setOxigeno(double oxigeno) {
        this.oxigeno = oxigeno;
    }

    public double getCo2() {
        return co2;
    }

    public void setCo2(double co2) {
        this.co2 = co2;
    }

    public double getVaporH2O() {
        return vaporH2O;
    }

    public void setVaporH2O(double vaporH2O) {
        this.vaporH2O = vaporH2O;
    }

    @Override
    public String toString(){
        return super.toString()+"% nitrogeno"+this.getNitrogeno()
                               +"% co2"+ this.getCo2()
                               +"% vapor h2o"+this.getVaporH2O()
                               +"% oxigeno"+this.getOxigeno();

    }
}

