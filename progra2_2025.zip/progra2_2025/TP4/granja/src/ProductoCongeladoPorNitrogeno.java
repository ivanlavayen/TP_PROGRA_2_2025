import java.time.LocalDate;

/*Los productos congelados por nitrógeno deben llevar la información del método
de congelación empleado y del tiempo de exposición al nitrógeno expresada en segundos*/
public class ProductoCongeladoPorNitrogeno extends ProductoRefrigerado{

    private String metodoCongelacion;
    private int tiempoExposicion;

    public ProductoCongeladoPorNitrogeno(String producto, LocalDate fechaVto, int nroLote,
                                         LocalDate fechaEnvasado, String granjaOrigen,
                                         String codigoOrganismoSupervisor, double temperaturaMantenimiento,
                                         String metodoCongelacion, int tiempoExposicion){
        super(producto,fechaVto,nroLote,fechaEnvasado,granjaOrigen,
                codigoOrganismoSupervisor,temperaturaMantenimiento);
        this.metodoCongelacion=metodoCongelacion;
        this.tiempoExposicion=tiempoExposicion;

    }

    public String getMetodoCongelacion() {
        return metodoCongelacion;
    }

    public void setMetodoCongelacion(String metodoCongelacion) {
        this.metodoCongelacion = metodoCongelacion;
    }

    public int getTiempoExposicion() {
        return tiempoExposicion;
    }

    public void setTiempoExposicion(int tiempoExposicion) {
        this.tiempoExposicion = tiempoExposicion;
    }

    @Override
    public String toString(){
        return super.toString()+"metodo congelacion"+this.metodoCongelacion
                               +"tiempo exposicion"+this.tiempoExposicion;
    }
}
