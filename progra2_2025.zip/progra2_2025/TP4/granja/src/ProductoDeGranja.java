import java.time.LocalDate;

public class ProductoDeGranja {
//producto, fecha de vencimiento y número de lote
   private String producto;
   private LocalDate fechaVto;
   private int nroLote;

   public ProductoDeGranja(String producto, LocalDate fechaVto, int nroLote){
       this.producto=producto;
       this.fechaVto=fechaVto;
       this.nroLote=nroLote;

   }



    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public LocalDate getFechaVto() {
        return fechaVto;
    }

    public void setFechaVto(LocalDate fechaVto) {
        this.fechaVto = fechaVto;
    }

    public int getNroLote() {
        return nroLote;
    }

    public void setNroLote(int nroLote) {
        this.nroLote = nroLote;
    }

    @Override
    public String toString() {
        return "Producto: " + this.producto + ", Fecha de Vencimiento: " + this.fechaVto + ", Numero de Lote: " + this.nroLote;
    }
}
