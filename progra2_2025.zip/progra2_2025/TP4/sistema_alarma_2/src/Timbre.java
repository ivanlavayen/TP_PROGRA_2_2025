public class Timbre {

    public void sonar(){
        System.out.println("ALARMA SONANDO!!!!!");
    }

}
