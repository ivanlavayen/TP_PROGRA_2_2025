public class Sensor {
    private String nombreZona;
    private boolean estado;

    public Sensor(String nombre, boolean estado) {
        this.nombreZona = nombre;
        this.estado=estado;

    }
    public String getNombreZona() {
        return nombreZona;
    }

    public void setNombre(String nombre) {
        this.nombreZona = nombre;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    //simulo activacion del sensor
    public void activar(){
        this.estado=true;
    }
}
