import java.util.ArrayList;

public class Alarma {

        private Timbre timbre;
        private ArrayList<Sensor> sensores;


        public Alarma() {
            this.sensores=new ArrayList<>();

            this.timbre=new Timbre();
        }

        public ArrayList<Sensor>getSensores(){
            return new ArrayList<>();
        }

        public boolean comprobarEstado() {
            for (Sensor s : sensores) {
                if ((s.getEstado())) {
                    timbre.sonar();
                    System.out.println(s.getNombreZona());

                }

            }
            return false;
        }



}

