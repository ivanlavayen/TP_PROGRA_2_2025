public class AlarmaSensorial {
}
