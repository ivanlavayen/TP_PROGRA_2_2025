public class Luz {

    public void encender(){
        System.out.println("LUCES ENCENDIDAS!!!!!" +
                "" );
    }
}
