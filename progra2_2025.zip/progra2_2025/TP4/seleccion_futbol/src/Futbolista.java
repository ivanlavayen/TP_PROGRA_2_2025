import java.time.LocalDate;

/*Los futbolistas, además, poseen una posición, si es zurdo o
derecho y la cantidad de goles convertidos*/
public class Futbolista extends Integrante{
    private int posicion;
    private String piernaHabil;
    private int cantidadGoles;

    public Futbolista(String nombre, String apellido, int nroPasaporte, LocalDate fechaNacimiento
                      ,String estado, int posicion, String piernaHabil, int cantidadGoles) {
        super(nombre, apellido, nroPasaporte, fechaNacimiento,estado);
        this.posicion = posicion;
        this.piernaHabil = piernaHabil;
        this.cantidadGoles = cantidadGoles;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public String getPiernaHabil() {
        return piernaHabil;
    }

    public void setPiernaHabil(String piernaHabil) {
        this.piernaHabil = piernaHabil;
    }

    public int getCantidadGoles() {
        return cantidadGoles;
    }

    public void setCantidadGoles(int cantidadGoles) {
        this.cantidadGoles = cantidadGoles;
    }
}
