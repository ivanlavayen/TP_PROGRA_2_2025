import java.time.LocalDate;

/*Cada integrante del contingente posee un nombre, apellido, número de
pasaporte y fecha de nacimiento*/
public class Integrante {
    private static String estado1="En país de origen";
    private static String estado2="Viajando";
    private static String estado3="Concentracion";
    private String nombre;
    private String apellido;
    private int nroPasaporte;
    LocalDate fechaNacimiento;
    private String estado;

    public Integrante(String nombre, String apellido, int nroPasaporte,
                      LocalDate fechaNacimiento, String estado) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nroPasaporte = nroPasaporte;
        this.fechaNacimiento = fechaNacimiento;
        this.estado=estado;
    }

    public String getEstado(){
        return this.estado;
    }
    public boolean isDisponible(){
        return (this.getEstado().equals(estado1)&&(!this.getEstado().equals(estado3)));
    }

}
