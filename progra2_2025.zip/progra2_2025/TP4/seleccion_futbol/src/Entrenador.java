import java.time.LocalDate;

/*ikmn */
public class Entrenador extends Integrante {
    private String identificador;

    public Entrenador(String nombre, String apellido,
                      int nroPasaporte, LocalDate fechaNacimiento,String estado, String identificador) {
        super(nombre, apellido, nroPasaporte, fechaNacimiento,estado);
        this.identificador = identificador;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }
}
